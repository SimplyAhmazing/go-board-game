from enum import Enum


class Color(Enum):
    black = 0
    white = 1
