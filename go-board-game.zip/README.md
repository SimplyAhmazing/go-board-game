## Go board game


## Tests

Run tests via,


```
python3 -m unittest
```
