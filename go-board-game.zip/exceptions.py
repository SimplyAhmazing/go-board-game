class IllegalGoPieceColorException(Exception):
    pass


class IllegalMoveException(Exception):
    pass

